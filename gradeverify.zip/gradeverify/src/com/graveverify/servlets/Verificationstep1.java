package com.graveverify.servlets;

import java.io.IOException;
import java.sql.DriverManager;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.servlet.http.HttpSession;

import com.graveverify.beans.CodeBar;
import com.graveverify.beans.Hash;
import com.graveverify.beans.Pdf;
import com.mysql.jdbc.Connection;
import com.mysql.jdbc.PreparedStatement;
import com.mysql.jdbc.Statement;

/**
 * Servlet implementation class Verificationstep1
 */
@WebServlet("/Verificationstep1")
public class Verificationstep1 extends HttpServlet {
	public static final String CHAMP_MATRICULE = "matricule";
	public static final String ATT_TITLE = "titre";
	public static final String CHAMP_ANNEE = "year";
	public static final String CHAMP_ECOLE = "school";
	public static final String CHAMP_DEPARTEMENT = "option";
	public static final String CHAMP_NIVEAU = "level";
	public static final String ATT_ERREURS = "erreurs";
	public static final String CHAMP_INFOS_ETUDIANT = "infos_etud";
	public static final String CHAMP_INFOS_NOTES = "liste_notes";
	public static final String ATT_VUE_HOME = "/WEB-INF/index.jsp";
	public static final String ATT_VUE_VERIF = "/WEB-INF/verificationfinal.jsp";
	String url = "jdbc:mysql://localhost:3306/gradeverify?useSSL=false";
	String utilisateur = "root";
	String motDePasse = "knrIn112@2017";
	String requette = "SELECT e.matricule,e.nom as nom , e.date_naissance as date , e.lieu_naissance as lieu FROM etudiant as e INNER JOIN releves as r ON e.matricule = r.matricule INNER JOIN niveaux as nv ON r.code_niveau = nv.codeNiv INNER JOIN annees as an ON r.code_annee = an.code_annee INNER JOIN ecoles as ec ON r.code_ecole = ec.code_ecole INNER JOIN options as op ON r.code_option = op.code_option WHERE r.matricule = ? and nv.valeur = ? and ec.valeur = ? and op.valeur = ? and an.valeur = ?";
	String requette2 = "SELECT n.code_mat as ue , n.note as note  FROM notes as n INNER JOIN etudiant as e   ON e.matricule = n.matricule INNER JOIN annees as an ON n.annee = an.code_annee WHERE e.matricule = ? and   an.valeur = ?";
	
	Connection connexion = null;
	Statement statement = null;
	ResultSet resultat = null;
	PreparedStatement preparedStatement = null;
	
	private static final long serialVersionUID = 1L;
       
    /**
     * @see HttpServlet#HttpServlet()
     */
    public Verificationstep1() {
        super();
        // TODO Auto-generated constructor stub
    }

	/**
	 * @see HttpServlet#doGet(HttpServletRequest request, HttpServletResponse response)
	 */
	protected void doGet(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		// TODO Auto-generated method stub
		doPost(request,response);
	}

	/**
	 * @see HttpServlet#doPost(HttpServletRequest request, HttpServletResponse response)
	 */
	protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		// TODO Auto-generated method stub

		
		HttpSession session = request.getSession();

		
		
		String matricule = (String) session.getAttribute(CHAMP_MATRICULE);
		String annee = (String) session.getAttribute(CHAMP_ANNEE);
		String ecole = (String) session.getAttribute(CHAMP_ECOLE);
		String departement = (String) session.getAttribute(CHAMP_DEPARTEMENT);
		String niveau = (String) session.getAttribute( CHAMP_NIVEAU);
		
		
		Map<String, String> valeurs = new HashMap<String, String>();
		Map<String, String> retourbd = new HashMap<String, String>();
		Map<String, String> retourbdnote = new HashMap<String, String>();
		
		

		
		valeurs.put(CHAMP_MATRICULE, matricule);
		valeurs.put(CHAMP_ANNEE, annee);
		valeurs.put(CHAMP_ECOLE, ecole);
		valeurs.put(CHAMP_DEPARTEMENT, departement);
		valeurs.put(CHAMP_NIVEAU, niveau);
		
		try 
		{
				Class.forName( "com.mysql.jdbc.Driver" );
		} 
		catch ( ClassNotFoundException e ) 
		{
			System.out.println(e);
		}			
		try 
		{
			connexion = (Connection) DriverManager.getConnection( url, utilisateur,
			motDePasse );
			
		    preparedStatement = (PreparedStatement)connexion.prepareStatement(requette );
		    preparedStatement.setString( 1, matricule);	
		    preparedStatement.setString( 2, niveau);
		    preparedStatement.setString( 3, ecole);
		    preparedStatement.setString( 4, departement);
		    preparedStatement.setString( 5, annee);
			resultat = preparedStatement.executeQuery();

			
			
			while ( resultat.next() ) 
			{
				retourbd.put("matricule" ,resultat.getString( "matricule" ));
				retourbd.put("nom" ,resultat.getString( "nom" ));
				retourbd.put("date_naissance" ,resultat.getString( "date" ));
				retourbd.put("lieu_naissance" ,resultat.getString( "lieu" ));
			
			}

			
		    preparedStatement = (PreparedStatement)connexion.prepareStatement(requette2 );
		    preparedStatement.setString( 1, matricule);	
		    preparedStatement.setString( 2, annee);	
		    
			resultat = preparedStatement.executeQuery();

			
			
			
			while ( resultat.next() ) 
			{
				retourbdnote.put(resultat.getString( "ue" ),resultat.getString( "note" ));
			}
			
			
			
			

		} 
		catch ( SQLException e ) 
		{
			System.out.println(e);
		} 
		finally 
		{
			if ( resultat != null ) 
			{
				try 
				{
					resultat.close();
				} 
				catch ( SQLException ignore ) {
				}
			}
			if ( statement != null ) 
			{
				try 
				{
				
					statement.close();
				} 
				catch ( SQLException ignore ) 
				{
				}
			}
			
			if ( preparedStatement != null ) 
			{
				try 
				{
				
					preparedStatement.close();
				} 
				catch ( SQLException ignore ) 
				{
				}
			}
			if ( connexion != null ) 
			{
				try 
				{
					connexion.close();
				} 
				catch ( SQLException ignore ) 
				{
				}
			}


		}
		
		
		
		String hash_val = Hash.encryptThisString(retourbdnote.toString());
		
		
	
		List<String> elemnts_codebar = new ArrayList<String>();
		
		elemnts_codebar.add(matricule);
		elemnts_codebar.add(ecole);
		elemnts_codebar.add(departement);
		elemnts_codebar.add(hash_val);
		
		String chemin_image = CodeBar.codegerer(elemnts_codebar);

		retourbd.put("chemin_image", chemin_image);
		retourbd.put("hash",hash_val );
		
		
		
		Pdf.generare(retourbd, retourbdnote);
		
		request.setAttribute("hash", hash_val);
		
		request.setAttribute(ATT_TITLE, "Grades Verify - End step");
		
		this.getServletContext().getRequestDispatcher(ATT_VUE_VERIF).forward(request, response);	
		
	}
	


}
