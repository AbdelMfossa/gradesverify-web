package com.graveverify.servlets;

import java.io.IOException;
import java.sql.DriverManager;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.HashMap;
import java.util.Map;

import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.servlet.http.HttpSession;

import com.mysql.jdbc.Connection;
import com.mysql.jdbc.PreparedStatement;
import com.mysql.jdbc.Statement;

/**
 * Servlet implementation class Home
 */
@WebServlet("/Home")
public class Home extends HttpServlet {
	public static final String CHAMP_MATRICULE = "matricule";
	public static final String ATT_TITLE = "titre";
	public static final String CHAMP_ANNEE = "year";
	public static final String CHAMP_ECOLE = "school";
	public static final String CHAMP_DEPARTEMENT = "option";
	public static final String CHAMP_NIVEAU = "level";
	public static final String ATT_ERREURS = "erreurs";
	public static final String CHAMP_INFOS_ETUDIANT = "infos_etud";
	public static final String CHAMP_INFOS_NOTES = "liste_notes";
	public static final String ATT_VUE_HOME = "/WEB-INF/index.jsp";
	public static final String ATT_VUE_VERIF = "/WEB-INF/verification.jsp";
	String url = "jdbc:mysql://localhost:3306/gradeverify?useSSL=false";
	String utilisateur = "root";
	String motDePasse = "knrIn112@2017";
	String requette = "SELECT e.matricule,e.nom as nom , e.date_naissance as date , e.lieu_naissance as lieu FROM etudiant as e INNER JOIN releves as r ON e.matricule = r.matricule INNER JOIN niveaux as nv ON r.code_niveau = nv.codeNiv INNER JOIN annees as an ON r.code_annee = an.code_annee INNER JOIN ecoles as ec ON r.code_ecole = ec.code_ecole INNER JOIN options as op ON r.code_option = op.code_option WHERE r.matricule = ? and nv.valeur = ? and ec.valeur = ? and op.valeur = ? and an.valeur = ?";
	String requette2 = "SELECT n.code_mat as ue , n.note as note  FROM notes as n INNER JOIN etudiant as e   ON e.matricule = n.matricule INNER JOIN annees as an ON n.annee = an.code_annee WHERE e.matricule = ? and   an.valeur = ?";
	String requette3 = "SELECT matricule  FROM  etudiant WHERE matricule = ?";
	
	Connection connexion = null;
	Statement statement = null;
	ResultSet resultat = null;
	PreparedStatement preparedStatement = null;

	private static final long serialVersionUID = 1L;
       
    /**
     * @see HttpServlet#HttpServlet()
     */
    public Home() {
        super();
        // TODO Auto-generated constructor stub
    }

	/**
	 * @see HttpServlet#doGet(HttpServletRequest request, HttpServletResponse response)
	 */
	protected void doGet(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		// TODO Auto-generated method stub
		HttpSession session = request.getSession();
		session.invalidate();
		request.setAttribute(ATT_TITLE, "Grades Verify");
		this.getServletContext().getRequestDispatcher(ATT_VUE_HOME).forward(request, response);
	}

	/**
	 * @see HttpServlet#doPost(HttpServletRequest request, HttpServletResponse response)
	 */
	protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		// TODO Auto-generated method stub
		
		
		String matricule = request.getParameter( CHAMP_MATRICULE);
		String annee = request.getParameter( CHAMP_ANNEE);
		String ecole = request.getParameter( CHAMP_ECOLE);
		String departement = request.getParameter( CHAMP_DEPARTEMENT);
		String niveau = request.getParameter( CHAMP_NIVEAU);
		
		
		
		Map<String, String> erreurs = new HashMap<String, String>();
		Map<String, String> valeurs = new HashMap<String, String>();
		Map<String, String> retourbd = new HashMap<String, String>();
		Map<String, String> retourbdnote = new HashMap<String, String>();
		Map<String, String> retourbdtest = new HashMap<String, String>();
		
		
		
		valeurs.put(CHAMP_MATRICULE, matricule);
		valeurs.put(CHAMP_ANNEE, annee);
		valeurs.put(CHAMP_ECOLE, ecole);
		valeurs.put(CHAMP_DEPARTEMENT, departement);
		valeurs.put(CHAMP_NIVEAU, niveau);
		
		
		try 
		{
				Class.forName( "com.mysql.jdbc.Driver" );
		} 
		catch ( ClassNotFoundException e ) 
		{
			System.out.println(e);
		}

		
		try 
		{
			validationMatricule(matricule);
		} 
		catch (Exception e) 
		{
			erreurs.put(CHAMP_ANNEE, e.getMessage());
			
		}
		
		try 
		{
			validationAnnee(annee);
		} 
		catch (Exception e) 
		{
			erreurs.put(CHAMP_ANNEE, e.getMessage());
			
		}
		

		try 
		{
			validationEcole(ecole);
		} 
		catch (Exception e) 
		{
			erreurs.put(CHAMP_ECOLE, e.getMessage());
		}
		
		

		try 
		{
			validationNiveau(niveau);
		} 
		catch (Exception e) 
		{
			erreurs.put(CHAMP_NIVEAU, e.getMessage());
		}
		
		

		try 
		{

			validationDepartement(departement);
		} 
		catch (Exception e) 
		{
			erreurs.put(CHAMP_DEPARTEMENT, e.getMessage());
		}
		
		
		
		request.setAttribute( ATT_ERREURS, erreurs );
		request.setAttribute( "val", valeurs);
		
		if ( erreurs.isEmpty() ) 
		{

			try 
			{
				connexion = (Connection) DriverManager.getConnection( url, utilisateur,
				motDePasse );
				
			    preparedStatement = (PreparedStatement)connexion.prepareStatement(requette3 );
			    preparedStatement.setString( 1, matricule);	
			    resultat = preparedStatement.executeQuery();
			    
				while ( resultat.next() ) 
				{
					retourbdtest.put("matricule" ,resultat.getString( "matricule" ));
				
				}			    
			    
			    
			    preparedStatement = (PreparedStatement)connexion.prepareStatement(requette );
			    preparedStatement.setString( 1, matricule);	
			    preparedStatement.setString( 2, niveau);
			    preparedStatement.setString( 3, ecole);
			    preparedStatement.setString( 4, departement);
			    preparedStatement.setString( 5, annee);
				resultat = preparedStatement.executeQuery();

				
				
				while ( resultat.next() ) 
				{
					retourbd.put("matricule" ,resultat.getString( "matricule" ));
					retourbd.put("nom" ,resultat.getString( "nom" ));
					retourbd.put("date_naissance" ,resultat.getString( "date" ));
					retourbd.put("lieu_naissance" ,resultat.getString( "lieu" ));
				
				}

				
			    preparedStatement = (PreparedStatement)connexion.prepareStatement(requette2 );
			    preparedStatement.setString( 1, matricule);	
			    preparedStatement.setString( 2, annee);	
			    
				resultat = preparedStatement.executeQuery();

				
				
				
				while ( resultat.next() ) 
				{
					retourbdnote.put(resultat.getString( "ue" ),resultat.getString( "note" ));
				}
				
				
				
				
				

			} 
			catch ( SQLException e ) 
			{
				System.out.println(e);
			} 
			finally 
			{
				if ( resultat != null ) 
				{
					try 
					{
						resultat.close();
					} 
					catch ( SQLException ignore ) {
					}
				}
				if ( statement != null ) 
				{
					try 
					{
					
						statement.close();
					} 
					catch ( SQLException ignore ) 
					{
					}
				}
				
				if ( preparedStatement != null ) 
				{
					try 
					{
					
						preparedStatement.close();
					} 
					catch ( SQLException ignore ) 
					{
					}
				}
				if ( connexion != null ) 
				{
					try 
					{
						connexion.close();
					} 
					catch ( SQLException ignore ) 
					{
					}
				}


			}
			
			  
			
			if(retourbdtest.isEmpty())
			{
				request.setAttribute( "bd_infos", "Cette Etudiant n'est pas inscrit dans notre academie"); 
				this.getServletContext().getRequestDispatcher(ATT_VUE_HOME).forward(request, response);
				
			}
			else if(retourbd.isEmpty() || retourbdnote.isEmpty())
			{
				request.setAttribute( "bd_infos", "Cette Etudiant est inscirt dans note academie mais l'authentification du certificat  demande est encore indisponible"); 
				this.getServletContext().getRequestDispatcher(ATT_VUE_HOME).forward(request, response);
			}
			else
			{
				HttpSession session = request.getSession();
				
				session.setAttribute(CHAMP_MATRICULE, matricule);
				session.setAttribute(CHAMP_ANNEE, annee);
				session.setAttribute(CHAMP_ECOLE, ecole);
				session.setAttribute(CHAMP_DEPARTEMENT, departement);
				session.setAttribute(CHAMP_NIVEAU, niveau);
				

				request.setAttribute( CHAMP_INFOS_ETUDIANT, retourbd);
				request.setAttribute( CHAMP_INFOS_NOTES, retourbdnote);
				

				request.setAttribute(ATT_TITLE, "Grades Verify - Next 1");
				this.getServletContext().getRequestDispatcher(ATT_VUE_VERIF).forward(request, response);
			}

		}
		else
		{
			this.getServletContext().getRequestDispatcher(ATT_VUE_HOME).forward(request, response);
		}
		




	}

	private void validationMatricule( String matricule) throws Exception 
	{
		if ( matricule == null || matricule.trim().length() == 0) 
		{
			throw new Exception( "Merci  de choisir votre niveau" );
		}
	}
	
	
	private void validationNiveau( String niveau ) throws Exception 
	{
		if ( niveau == null || niveau.trim().length() == 0) 
		{
			throw new Exception( "Merci  de choisir votre niveau" );
		}
	}
	
	private void validationAnnee( String annee) throws Exception 
	{
		if ( annee == null || annee.trim().length() == 0) 
		{
			throw new Exception( "Merci  une choisir votre annee" );
		}
	}

	private void validationEcole( String ecole ) throws Exception 
	{
		if ( ecole == null || ecole.trim().length() == 0) 
		{
			throw new Exception( "Merci  de choisir votre falculte " );
		}
	}
	
	private void validationDepartement( String departement ) throws Exception 
	{
		if ( departement == null || departement.trim().length() == 0) 
		{
			throw new Exception( "Merci  de choisir votre departement" );
		}
	}	

}
