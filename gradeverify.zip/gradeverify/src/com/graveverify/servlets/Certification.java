package com.graveverify.servlets;

import java.io.FileInputStream;
import java.io.IOException;
import java.io.PrintWriter;

import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

/**
 * Servlet implementation class Certificat
 */
@WebServlet("/Certificaton")
public class Certification extends HttpServlet {
	public static final String ATT_VUE_VERIF = "/WEB-INF/verificationfinaltelechargement.jsp";
	private static final long serialVersionUID = 1L;
       
    /**
     * @see HttpServlet#HttpServlet()
     */
    public Certification() {
        super();
        // TODO Auto-generated constructor stub
    }

	/**
	 * @see HttpServlet#doGet(HttpServletRequest request, HttpServletResponse response)
	 */
	protected void doGet(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		// TODO Auto-generated method stub
		
		
		String currentDirectory = System.getProperty("user.home");
			   
		 currentDirectory = currentDirectory + "\\eclipse-workspace";
		    
		 currentDirectory = currentDirectory + "\\gradeverify\\WebContent\\assets\\pdf\\";
		 
		 
		 
			response.setContentType("text/html");
			PrintWriter out = response.getWriter();
			String gurufile = "Certificat.pdf";
			String gurupath = currentDirectory;
			response.setContentType("APPLICATION/OCTET-STREAM");
			response.setHeader("Content-Disposition", "attachment; filename=\""
					+ gurufile + "\"");
	 
			FileInputStream fileInputStream = new FileInputStream(gurupath
					+ gurufile);
	 
			int i;
			while ((i = fileInputStream.read()) != -1) {
				out.write(i);
			}
			fileInputStream.close();
			out.close();

			request.setAttribute("title", "telechargement certificat");
			
			this.getServletContext().getRequestDispatcher(ATT_VUE_VERIF).forward(request, response);
		
	}

	/**
	 * @see HttpServlet#doPost(HttpServletRequest request, HttpServletResponse response)
	 */
	protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		// TODO Auto-generated method stub
		doGet(request, response);
	}

}
