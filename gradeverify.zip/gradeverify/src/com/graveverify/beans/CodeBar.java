package com.graveverify.beans;

import java.io.ByteArrayOutputStream;
import java.io.File;
import java.io.FileNotFoundException;
import java.io.FileOutputStream;
import java.io.IOException;
import java.util.List;

import net.glxn.qrgen.QRCode;
import net.glxn.qrgen.image.ImageType;
  
public class CodeBar { 
  
    public static String codegerer(List<String> args) 
    { 
    	
    	String conntenue = args.get(0) + "," +args.get(1)+","+args.get(2)+ "," + args.get(3); 
	    ByteArrayOutputStream out = QRCode.from(conntenue).to(ImageType.PNG).stream();
	    String currentDirectory = System.getProperty("user.home");
	   
	    currentDirectory = currentDirectory + "\\eclipse-workspace";
	    
	    currentDirectory = currentDirectory + "\\QR_Code.JPG";
	    
	    
		try 
		{
			FileOutputStream fout = new FileOutputStream(new File(currentDirectory));
			fout.write(out.toByteArray());
			fout.flush();
			fout.close();
		} 
		catch (FileNotFoundException e) 
		{
		} 
		catch (IOException e) 
		{
		}
		
		return currentDirectory;
    }
} 