package com.graveverify.beans;

public class Etudiant {
	private String maricule;
	private String  annee;
	private String ecole;
	private String option;
	private String niveau;
	public String getMaricule() {
		return maricule;
	}
	public void setMaricule(String maricule) {
		this.maricule = maricule;
	}
	public String getAnnee() {
		return annee;
	}
	public void setAnnee(String annee) {
		this.annee = annee;
	}
	public String getEcole() {
		return ecole;
	}
	public void setEcole(String ecole) {
		this.ecole = ecole;
	}
	public String getOption() {
		return option;
	}
	public void setOption(String option) {
		this.option = option;
	}
	public String getNiveau() {
		return niveau;
	}
	public void setNiveau(String niveau) {
		this.niveau = niveau;
	}

	
}
