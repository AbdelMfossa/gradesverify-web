package com.graveverify.beans;




import java.io.FileOutputStream;
import java.util.Map;

import com.itextpdf.text.BaseColor;
import com.itextpdf.text.Document;
import com.itextpdf.text.Element;
import com.itextpdf.text.Font;
import com.itextpdf.text.FontFactory;
import com.itextpdf.text.Image;
import com.itextpdf.text.ListItem;
import com.itextpdf.text.Paragraph;
import com.itextpdf.text.pdf.CMYKColor;
import com.itextpdf.text.pdf.PdfPCell;
import com.itextpdf.text.pdf.PdfPTable;
import com.itextpdf.text.pdf.PdfWriter;
import com.itextpdf.text.List;



public class Pdf {

	private static <K, V> V getKey(Map<K, V> map, K value) {
		for (Map.Entry<K, V> entry : map.entrySet()) {
			if (value.equals(entry.getKey())) {
				return entry.getValue();
			}
		}
		return null;
	}
	
	
	public static String generare(Map<String,String> liseinfos,Map<String,String> lisenotest) 
	{
		Document document = new Document(); 
		
		String currentDirectory = System.getProperty("user.home");
		
		Paragraph monparagraphe = new Paragraph();
		Paragraph monparagraphe1 = new Paragraph();
		PdfPCell cell1 = new PdfPCell();
		PdfPCell cell2 = new PdfPCell();
	
		
		
		try
		{
		    
		   
		   
		    currentDirectory = currentDirectory + "\\eclipse-workspace";
		    
		    currentDirectory = currentDirectory + "\\gradeverify\\WebContent\\assets\\pdf\\Certificat.pdf";
		    
		    Font normaleTextFont = FontFactory.getFont(FontFactory.TIMES_ROMAN, 15, Font.NORMAL, new CMYKColor(0, 0, 0, 0));
		    Font normaleSmallTextFont = FontFactory.getFont(FontFactory.TIMES_ROMAN, 8, Font.NORMAL, new CMYKColor(0, 0, 0, 0));
		    Font normaleBigTextFont = FontFactory.getFont(FontFactory.TIMES_BOLD, 10 , Font.BOLD, new CMYKColor(0, 0, 0, 0));
		    Font normaleBigspanceTextFont = FontFactory.getFont(FontFactory.TIMES_BOLD, 17 , Font.NORMAL, new CMYKColor(0, 0, 0, 0));
		    
			PdfWriter writer = PdfWriter.getInstance(document, new FileOutputStream(currentDirectory));
			
			document.open();
			
			

			monparagraphe = new Paragraph("FACULTE DES SCIENCES");
			monparagraphe.setFont(normaleTextFont);
			monparagraphe.setAlignment(1);

			document.add(monparagraphe);
			
			
			monparagraphe = new Paragraph("BP/P.O.Box 812 Yaoundé-CAMROUN /Tél:22 23 44 96/Email:diplome@facsciences.uy1.cm");
			monparagraphe.setFont(normaleSmallTextFont);
			monparagraphe.setAlignment(1);
			document.add(monparagraphe);
			

			monparagraphe = new Paragraph("RELEVE DE NOTES/TRANSCRIPT");
			monparagraphe.setFont(normaleBigTextFont);
			monparagraphe.setAlignment(1);
			document.add(monparagraphe);


			
			monparagraphe = new Paragraph("Noms et Prénoms : " + getKey(liseinfos , "nom") + "                      " +"Matricule : " + getKey(liseinfos , "matricule"));
			monparagraphe.setFont(normaleBigspanceTextFont);
			document.add(monparagraphe);


			monparagraphe = new Paragraph("Né(e) le : " + getKey(liseinfos , "date_naissance") + "                      " +"A : " + getKey(liseinfos , "lieu_naissance"));
			monparagraphe.setFont(normaleSmallTextFont);
			document.add(monparagraphe);
			
			PdfPTable table = new PdfPTable(2);
			table.setWidthPercentage(100);
			table.setSpacingBefore(10f);
			table.setSpacingAfter(10f);

			

			cell1 = new PdfPCell(new Paragraph("CODE UE"));
			cell1.setBorderColor(BaseColor.BLACK);
			cell1.setPaddingLeft(10);
			cell1.setHorizontalAlignment(Element.ALIGN_CENTER);
			cell1.setVerticalAlignment(Element.ALIGN_MIDDLE);
			table.addCell(cell1);

			cell2 = new PdfPCell(new Paragraph("MOYENNE"));
			cell2.setBorderColor(BaseColor.BLACK);
			cell2.setPaddingLeft(10);
			cell2.setHorizontalAlignment(Element.ALIGN_CENTER);
			cell2.setVerticalAlignment(Element.ALIGN_MIDDLE);
			table.addCell(cell2);
			
			//Set Column widths
			float[] columnWidths = {1f, 1f,};
			table.setWidths(columnWidths);
			
			
			for (Map.Entry<String, String> entry : lisenotest.entrySet()) 
			{
				
				cell1 = new PdfPCell(new Paragraph(entry.getKey()));
				cell1.setBorderColor(BaseColor.BLACK);
				cell1.setPaddingLeft(10);
				cell1.setHorizontalAlignment(Element.ALIGN_CENTER);
				cell1.setVerticalAlignment(Element.ALIGN_MIDDLE);
				table.addCell(cell1);

				
				cell2 = new PdfPCell(new Paragraph(entry.getValue()));
				cell2.setBorderColor(BaseColor.BLACK);
				cell2.setPaddingLeft(10);
				cell2.setHorizontalAlignment(Element.ALIGN_CENTER);
				cell2.setVerticalAlignment(Element.ALIGN_MIDDLE);
				table.addCell(cell2);

			}
			
			
			document.add(table);

			
		
			
			
			monparagraphe = new Paragraph();
			monparagraphe.add(getKey(liseinfos , "hash"));
			document.add(monparagraphe);
			
			
			
			monparagraphe = new Paragraph();
			String chemin_image = getKey(liseinfos , "chemin_image");
			Image image1 = Image.getInstance(chemin_image);
			image1.scaleAbsolute(200, 200);
			monparagraphe.add(image1);
			document.add(monparagraphe);
			
			

			
			

			

			document.close();
			writer.close();
			
		} catch (Exception e)
		{
			e.printStackTrace();
		}
		
		
		return currentDirectory;
	}
	
	
	
	

}
